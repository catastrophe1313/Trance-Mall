package anxing;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class checkinfo
 */
@WebServlet("/infoedit")
public class infoedit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public infoedit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//�������Ӧ�ı���
				request.setCharacterEncoding("utf-8");
				response.setCharacterEncoding("utf-8");
				String realname = request.getParameter("realname");
				String idtype = request.getParameter("idtype");
				String idnum = request.getParameter("idnum");
				String sex = request.getParameter("sex");
				String city = request.getParameter("city");
				
				request.setAttribute("realname", realname);
				request.setAttribute("idtype", idtype);
				request.setAttribute("idnum", idnum);
				request.setAttribute("sex", sex);
				request.setAttribute("city", city);
				//ת��
				request.getRequestDispatcher("info.jsp").forward(request, response);				
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
